## libmqttc
This is a simple mqtt client library based on paho.mqtt(29ab2aa).

sudo apt install mosquitto

1.mosquitto_sub -h localhost -t "will topic" -P "testpassword" -u "testuser" -v
2.test_libmqttc

