## libconfig
This is a simple configure library.
Support ini, json

## Backend
* ini parser
* json parser
* lua parser, depend on lua library (>= liblua5.2)
  LutTables++ source code is from https://bitbucket.org/MartinFelis/luatables  
  `$ sudo apt-get install liblua5.2-dev`

