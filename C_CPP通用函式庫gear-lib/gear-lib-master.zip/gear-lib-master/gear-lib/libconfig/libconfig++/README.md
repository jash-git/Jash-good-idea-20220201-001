## libgconfig
This is a simple libgconfig c++ library.
Support lua, json

### Backend
* lua parser, depend on liblua
* json parser, depend on jsoncpp
