## libplugin
This is a simple libplugin library.

