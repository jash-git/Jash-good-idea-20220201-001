## libp2p
This is a simple libp2p library.

## Dependency
* [liblog](../liblog/)
* [libgevent](../libgevent/)
* [libdict](../libdict/)
* [libsock](../libsock/)
* [libthread](../libthread/)
* [librpc](../librpc/)

Libptcp is a library, implementing a Pseudo Tcp Socket for use over UDP. The socket will implement a subset of the TCP stack to allow for a reliable transport over non-reliable sockets (such as UDP).
Rewrite based on libnice https://github.com/libnice/libnice.git
git commit fc41eedfcd7961d8ebb0002e2007f292ed6ceb82
proto based on libjingle

