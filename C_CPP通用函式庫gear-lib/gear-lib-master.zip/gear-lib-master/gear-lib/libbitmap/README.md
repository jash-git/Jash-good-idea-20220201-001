## libbitmap
This is a simple libbitmap library.

