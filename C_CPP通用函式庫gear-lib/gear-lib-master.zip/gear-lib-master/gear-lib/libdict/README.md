## libdict
This is a simple libdict library.

The key-value store type is string:string.

The code is based on dict from http://ndevilla.free.fr

Fix some double free bugs, and can be used easily.
