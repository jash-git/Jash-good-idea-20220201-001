## libringbuffer
This is a simple libringbuffer library.

