## libhomekit
This is a simple libhomekit library.

tools/gen_qrcode 5 123-45-678 1QJ8 qrcode.png
