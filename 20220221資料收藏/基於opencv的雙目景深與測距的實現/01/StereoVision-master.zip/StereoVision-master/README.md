StereoVision
============

stereo matching based on OpenCV 2.4.9 and VS 2012
