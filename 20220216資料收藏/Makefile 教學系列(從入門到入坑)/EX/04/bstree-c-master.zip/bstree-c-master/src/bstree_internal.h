#ifndef BSTREE_INTERNAL_H
#define BSTREE_INTERNAL_H

#include "bstnode.h"

struct bstree_int_t {
    node_int_t *root;
};

#endif  // BSTREE_INTERNAL_H
