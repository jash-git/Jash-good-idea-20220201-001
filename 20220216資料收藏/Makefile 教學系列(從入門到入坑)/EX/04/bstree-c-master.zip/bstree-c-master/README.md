# Binary Search Tree in C

This repo demos a naive (not balanced) binary search tree in C.

## Warning

For demo only. DON'T USE IT ON PRODUCTION ENVIRONMENT.

## Copyright

Copyright (c) 2019 Michelle Chen. Licensed under MIT
