## Finding Shapes

### Some Results


Original Image

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FindShapes/images/someshapes.jpg" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FindShapes/images/someshapes.jpg" width="500" height="300" />


Identified Shapes

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FindShapes/Example%20-%20findShapes.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FindShapes/Example%20-%20findShapes.png" width="500" height="300" />


Sorted on area

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FindShapes/Example%20-%20sortOnArea.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/FindShapes/Example%20-%20sortOnArea.png" width="500" height="300" />
