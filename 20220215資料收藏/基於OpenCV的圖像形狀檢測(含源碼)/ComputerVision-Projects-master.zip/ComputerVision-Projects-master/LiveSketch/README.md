## Live Sketch Demo

### Some Results


Normal Thresholding

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/LiveSketch/Example-Normal%20Threshold.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/LiveSketch/Example-Normal%20Threshold.png" width="300" height="300" />


Adaptive Thresholding

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/LiveSketch/Example-Adaptive%20Threshold.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/LiveSketch/Example-Adaptive%20Threshold.png" width="300" height="300" />


Other Examples

<img src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/LiveSketch/More%20examples.png" alt="" data-canonical-src="https://github.com/akshaybhatia10/ComputerVison-Projects/blob/master/LiveSketch/More%20examples.png" width="300" height="300" />
