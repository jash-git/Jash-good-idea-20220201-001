## Give Cartoon Effects to images.

Reference Link : http://datahacker.rs/002-opencv-projects-how-to-cartoonize-an-image-with-opencv-in-python/

# Original Image
<img src="https://github.com/prateekmaj21/Image-Processing-Tasks/blob/main/Cartoon%20Effect%20to%20Photos/person.jpeg" width="500" height="750"/>

# Cartoon Effect
<img src="https://github.com/prateekmaj21/Image-Processing-Tasks/blob/main/Cartoon%20Effect%20to%20Photos/cartoon.jpg" width="500" height="750"/>

