## Give Cartoon Effects to images.

# Original Image
<img src="https://github.com/prateekmaj21/Image-Processing-Tasks/blob/main/Cartoon%20Effect%20to%20Photos%20Type%202/person1.jpeg" width="800" height="480"/>

# Cartoon Effect
<img src="https://github.com/prateekmaj21/Image-Processing-Tasks/blob/main/Cartoon%20Effect%20to%20Photos%20Type%202/cartoon_final.jpg" width="800" height="480"/>
