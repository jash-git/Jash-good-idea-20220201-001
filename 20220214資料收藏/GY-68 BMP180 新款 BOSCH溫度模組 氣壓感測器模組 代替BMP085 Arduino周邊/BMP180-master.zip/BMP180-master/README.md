# BMP180 Library

Library for using the [BMP180](https://oberguru.net/elektronik/bmp180/bmp180.html) temperature sensor in Arduino projects.

Written by Christian Paul, 2014-2015.
This software is released under the terms of the MIT license.
See the file LICENSE or LIZENZ for details, please.

See the examples for using the library.



